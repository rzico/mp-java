package net.wit.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import org.hibernate.validator.constraints.Length;
import javax.persistence.*;
import javax.validation.constraints.Digits;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by Xus on 2018/2/9.
 * 选题组卷表(wx_test_paper)
 */

@Entity
@Table(name = "wx_testpaper")
@SequenceGenerator(name = "sequenceGenerator", sequenceName = "wx_testpaper_sequence")
public class TestPaper extends BaseEntity {

    private static final long serialVersionUID = 1L;

    /** 测试卷主标题 */
    @NotNull
    @Length(max = 100)
    @Column(nullable = false, length = 100, columnDefinition="varchar(100) not null comment '测试卷主标题'")
    private String testpapermaintitle;

    /** 测试卷副标题 */
    @NotNull
    @Length(max = 100)
    @Column(nullable = false, length = 100, columnDefinition="varchar(100) not null comment '测试卷副标题'")
    private String testpapersubheading;

    /** 测试卷类别 */
    @NotNull
    @Length(max = 100)
    @Column(nullable = false,columnDefinition="int(11) not null comment '测试卷类别'")
    private Integer testpapercategory;

    /** 测试卷题库编号数组(json串形式组合) */
    @NotNull
    @Length(max = 200)
    @Column(nullable = false, length = 200, columnDefinition="varchar(200) not null comment '测试卷题库编号数组'")
    private String questionarray;

    /** 测试卷介绍 */
    @NotNull
    @Length(max = 200)
    @Column(nullable = false, length = 200, columnDefinition="varchar(200) not null comment '测试卷介绍'")
    private String testpaperdesc;

    /** 测试卷须知 */
    @NotNull
    @Length(max = 200)
    @Column(nullable = false, length = 200, columnDefinition="varchar(200) not null comment '测试卷须知'")
    private String testpapernitice;

    /** 销售价 */
    @Min(0)
    @Digits(integer = 12, fraction = 3)
    @Column(precision = 21, scale = 6,columnDefinition="decimal(21,6) not null default 0 comment '销售价'")
    private BigDecimal price;

    /** 市场价 */
    @Min(0)
    @Digits(integer = 12, fraction = 3)
    @Column(precision = 21, scale = 6,columnDefinition="decimal(21,6) not null default 0 comment '市场价'")
    private BigDecimal marketPrice;

    /** 测试卷题数 */
    @Column(nullable = false,columnDefinition="int(11) not null comment '测试卷题数'")
    private Integer count;

    /** 测试卷已测试人数 */
    @Column(nullable = false,columnDefinition="int(11) not null comment '测试卷已测试人数'")
    private Integer peoplesum;

    /** 测试卷报告页数 */
    @Column(nullable = false,columnDefinition="int(11) not null comment '测试卷报告页数'")
    private Integer pagesum;

    /** 测试卷标签*/
    @ManyToMany(fetch = FetchType.LAZY)
    @JoinTable(name = "wx_tag")
    @OrderBy("orders asc")
    @JsonIgnore
    private List<Tag> tags = new ArrayList<Tag>();

}
