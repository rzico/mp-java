package net.wit.entity;

import org.hibernate.validator.constraints.Length;
import javax.persistence.*;
import javax.validation.constraints.Digits;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import java.math.BigDecimal;

/**
 * Created by Xus on 2018/2/9.
 * 测评题库表(wx_questionbank)
 */

@Entity
@Table(name = "wx_questionbank")
@SequenceGenerator(name = "sequenceGenerator", sequenceName = "wx_questionbank_sequence")
public class QuestionBank extends BaseEntity {
    private static final long serialVersionUID = 1L;

    /** 答题标题 */
    @NotNull
    @Length(max = 100)
    @Column(nullable = false, length = 100, columnDefinition="varchar(100) not null comment '答题标题'")
    private String questiontitle;

    /** 答题类型(0:单选 1:多选) */
    @Column(nullable = false, columnDefinition="int(11) not null default 0 comment '答题类型'")
    private Integer questiontype;

    /** 答题选项 */
    @NotNull
    @Length(max = 500)
    @Column(nullable = false, length = 500, columnDefinition="varchar(500) not null comment '答题选项'")
    private String questionoption;

    /** 答题所属类别 */
    @Column(nullable = false, columnDefinition="int(11) not null default 0 comment '答题所属类别'")
    private Integer questioncategory;

    public String getQuestiontitle() {
        return questiontitle;
    }

    public void setQuestiontitle(String questiontitle) {
        this.questiontitle = questiontitle;
    }

    public Integer getQuestiontype() {
        return questiontype;
    }

    public void setQuestiontype(Integer questiontype) {
        this.questiontype = questiontype;
    }

    public String getQuestionoption() {
        return questionoption;
    }

    public void setQuestionoption(String questionoption) {
        this.questionoption = questionoption;
    }

    public Integer getQuestioncategory() {
        return questioncategory;
    }

    public void setQuestioncategory(Integer questioncategory) {
        this.questioncategory = questioncategory;
    }

}
