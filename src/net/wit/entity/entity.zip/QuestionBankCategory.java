package net.wit.entity;

import org.hibernate.validator.constraints.Length;
import javax.persistence.*;
import javax.validation.constraints.Digits;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import java.math.BigDecimal;

/**
 * Created by Xus on 2018/2/9.
 * 测评题库分类表(wx_questionbank_category)
 */

@Entity
@Table(name = "wx_questionbank_category")
@SequenceGenerator(name = "sequenceGenerator", sequenceName = "wx_questionbank_category_sequence")
public class QuestionBankCategory extends BaseEntity {

    private static final long serialVersionUID = 1L;




}
