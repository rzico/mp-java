package net.wit.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import org.hibernate.validator.constraints.Length;
import javax.persistence.*;
import javax.validation.constraints.Digits;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import java.math.BigDecimal;

/**
 * Created by Xus on 2018/2/9.
 */

@Entity
@Table(name = "wx_testpaper_answer")
@SequenceGenerator(name = "sequenceGenerator", sequenceName = "wx_testpaper_answer_sequence")
public class TestPaperAnswer extends BaseEntity {

    private static final long serialVersionUID = 1L;

    /**
     * 测评状态
     */
    public enum AnswerStatus {

        /** 未完成 */
        unfinished,

        /** 已完成 */
        completed,

        /** 已推广 */
        extension

    }

    /** 测试卷 */
    @NotNull
    @ManyToOne(fetch = FetchType.LAZY)
    @JsonIgnore
    private TestPaper testpaper;

    /** 会员 */
    @NotNull
    @ManyToOne(fetch = FetchType.LAZY)
    @JsonIgnore
    private Member member;

    /** 会员答题(json串形式组合) */
    @NotNull
    @Length(max = 200)
    @Column(nullable = false, length = 200, columnDefinition="varchar(200) not null comment '会员答题'")
    private String answerquestion;

    /** 答题所得分数 */
    @Column(nullable = false, columnDefinition="int(11) not null default 0 comment '答题所得分数'")
    private Integer answerscore;

    /** 测评状态 */
    @Column(nullable = false,columnDefinition="int(11) not null comment '测评状态'")
    private AnswerStatus answerStatus;

}
